package ${IJ_BASE_PACKAGE}.controllers;

import ${IJ_BASE_PACKAGE}.data.Tester;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

/**
 * *******************************
 * Created by Irina.Petrovskaya on 2/6/2016.
 * Project: javaonly_jsp2ViewResolver
 * *******************************
 */
@Controller
public class MyController2 {

    private static List<Tester> currentTesters = new ArrayList<Tester>();


    static {
        currentTesters.add(new Tester("Irina", "Petrovskaya"));
        currentTesters.add(new Tester("Alexander", "Chernikov"));
        currentTesters.add(new Tester("Vika", "Dumova"));
        currentTesters.add(new Tester("Daria", "Isachenkova"));
        currentTesters.add(new Tester("Nikolay", "Sandalov"));
        currentTesters.add(new Tester("Maria", "Vdovina"));
        currentTesters.add(new Tester("Maria", "Timofeeva"));
    }
    @RequestMapping("/")
    public String defaultPath(Model model){
        model.addAttribute("currentGroup",currentTesters);
        model.addAttribute("amount",currentTesters.size());
        return "home";
    }
}
